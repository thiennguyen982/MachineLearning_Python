# Databricks notebook source
pip install google.auth

# COMMAND ----------

pip install google_auth_oauthlib

# COMMAND ----------

pip install google-api-python-client

# COMMAND ----------

pip install BeautifulSoup4