# Databricks notebook source
print('secend_notebook')

# COMMAND ----------

b=2000