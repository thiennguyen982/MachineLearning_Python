# Databricks notebook source
print('first_notebook')

# COMMAND ----------

a=1000